import React, { useState } from "react";
import { ShoppingCart } from "lucide-react";

const products = [
  { id: 1, model: "iPhone 15", priceUSD: 899, color: "Черный", storage: "128GB" },
  { id: 2, model: "iPhone 14", priceUSD: 799, color: "Белый", storage: "256GB" },
  { id: 3, model: "iPhone 13", priceUSD: 699, color: "Синий", storage: "128GB" },
  { id: 4, model: "iPhone 15", priceUSD: 999, color: "Красный", storage: "256GB" },
];

const currencyRates = {
  USD: 1,
  RUB: 90,
  PLN: 4,
};

const languagePack = {
  ru: {
    title: "Каталог iPhone",
    addToCart: "В корзину",
    currency: { USD: "Доллар", RUB: "Рубль", PLN: "Злотый" },
    filter: "Фильтр",
    color: "Цвет",
    storage: "Память",
    viewDetails: "Подробнее",
    back: "Назад",
    order: "Оформить заказ",
  },
  en: {
    title: "iPhone Catalog",
    addToCart: "Add to cart",
    currency: { USD: "USD", RUB: "RUB", PLN: "PLN" },
    filter: "Filter",
    color: "Color",
    storage: "Storage",
    viewDetails: "View details",
    back: "Back",
    order: "Place Order",
  },
};

export default function App() {
  const [lang, setLang] = useState("ru");
  const [currency, setCurrency] = useState("USD");
  const [cart, setCart] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [filterColor, setFilterColor] = useState("");
  const [filterStorage, setFilterStorage] = useState("");

  const t = languagePack[lang];

  const convertPrice = (usd) => (usd * currencyRates[currency]).toFixed(2);

  const filteredProducts = products.filter((p) => {
    return (
      (!filterColor || p.color === filterColor) &&
      (!filterStorage || p.storage === filterStorage)
    );
  });

  if (selectedProduct) {
    return (
      <div className="p-4">
        <button onClick={() => setSelectedProduct(null)} className="mb-4">
          ← {t.back}
        </button>
        <div className="max-w-md mx-auto rounded-xl shadow-md border p-6">
          <h2 className="text-2xl font-bold mb-2">{selectedProduct.model}</h2>
          <p className="mb-2">{t.color}: {selectedProduct.color}</p>
          <p className="mb-2">{t.storage}: {selectedProduct.storage}</p>
          <p className="mb-4 font-semibold">
            {convertPrice(selectedProduct.priceUSD)} {currency}
          </p>
          <button
            onClick={() => {
              setCart([...cart, selectedProduct]);
              setSelectedProduct(null);
            }}
            className="w-full bg-blue-600 text-white p-2 rounded"
          >
            {t.addToCart}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 bg-gray-100">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">RETECH</h1>
        <div className="flex gap-4 items-center">
          <select onChange={(e) => setLang(e.target.value)} className="p-1 rounded">
            <option value="ru">Русский</option>
            <option value="en">English</option>
          </select>
          <select onChange={(e) => setCurrency(e.target.value)} className="p-1 rounded">
            <option value="USD">{t.currency.USD}</option>
            <option value="RUB">{t.currency.RUB}</option>
            <option value="PLN">{t.currency.PLN}</option>
          </select>
          <ShoppingCart /> {cart.length}
        </div>
      </header>

      <h2 className="text-xl font-semibold mb-4">{t.title}</h2>

      <div className="flex gap-4 mb-4">
        <div>
          <label>{t.color}: </label>
          <select onChange={(e) => setFilterColor(e.target.value)} className="p-1 rounded">
            <option value="">--</option>
            <option value="Черный">Черный</option>
            <option value="Белый">Белый</option>
            <option value="Синий">Синий</option>
            <option value="Красный">Красный</option>
          </select>
        </div>
        <div>
          <label>{t.storage}: </label>
          <select onChange={(e) => setFilterStorage(e.target.value)} className="p-1 rounded">
            <option value="">--</option>
            <option value="128GB">128GB</option>
            <option value="256GB">256GB</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filteredProducts.map((product) => (
          <div key={product.id} className="rounded-xl shadow-md border p-4">
            <h3 className="text-lg font-bold mb-2">{product.model}</h3>
            <p>{t.color}: {product.color}</p>
            <p>{t.storage}: {product.storage}</p>
            <p className="mb-4 font-semibold">
              {convertPrice(product.priceUSD)} {currency}
            </p>
            <button
              onClick={() => setSelectedProduct(product)}
              className="w-full mb-2 bg-gray-200 p-2 rounded"
            >
              {t.viewDetails}
            </button>
            <button
              onClick={() => setCart([...cart, product])}
              className="w-full bg-blue-600 text-white p-2 rounded"
            >
              {t.addToCart}
            </button>
          </div>
        ))}
      </div>

      {cart.length > 0 && (
        <div className="fixed bottom-4 right-4 bg-white shadow-lg p-4 rounded-xl">
          <h3 className="font-bold mb-2">🛒 {cart.length} {lang === "ru" ? "товаров" : "items"}</h3>
          <button className="bg-green-600 text-white w-full mt-2 p-2 rounded">
            {t.order}
          </button>
        </div>
      )}
    </div>
  );
}